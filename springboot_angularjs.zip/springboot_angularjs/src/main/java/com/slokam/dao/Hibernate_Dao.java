package com.slokam.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.slokam.pojo.StudentPojo;

@EnableJpaRepositories
public interface Hibernate_Dao extends JpaRepository<StudentPojo, Integer>{

}
