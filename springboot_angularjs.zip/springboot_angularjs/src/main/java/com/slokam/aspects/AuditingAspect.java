package com.slokam.aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.slokam.dao.AuditingDao;
import com.slokam.pojo.Auditable;
import com.slokam.service.AuditingService;

@Aspect
@Component
@Scope("session")
public class AuditingAspect {
	@Autowired
	private AuditingService ser ;
	
	private Object prevObj;
	
	@AfterReturning(pointcut="execution(* com.slokam.controller.*.getBy* (..))",returning="object")
	public void afterReturngetByid(JoinPoint joinPoint,Object object){
		prevObj=object;
		System.out.println(joinPoint.getTarget());
	}
	
	@Before("execution(* com.slokam.controller.*.saveOrUpdate* (..))")
	public void beforesave(JoinPoint joinPoint){
		Object[] objs=joinPoint.getArgs();
		for (Object object : objs) {
			if(object instanceof Auditable)
				ser.audit(prevObj, object);
		}
	}
}
