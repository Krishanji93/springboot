package com.slokam.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.slokam.service.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
public class SecurityConfigs extends WebSecurityConfigurerAdapter{
	@Autowired
	private UserDetailsServiceImpl userdeatilsService; 
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable()
		.formLogin().loginProcessingUrl("/loginProcessingUrl")
		.usernameParameter("user").passwordParameter("password")
		.defaultSuccessUrl("/loginsuccess")
		.failureUrl("/failure")
		.and().logout()
		.invalidateHttpSession(true)
		.logoutUrl("/logoutUrl").logoutSuccessUrl("/login")
		.clearAuthentication(true);/*.and().authorizeRequests().antMatchers("").;*/
		
	}
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		//auth.inMemoryAuthentication().withUser("krishnaji").password("krish8666").roles("USER");
		auth.userDetailsService(userdeatilsService);
	}

	
}
