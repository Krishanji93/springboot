package com.slokam.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="auditing")
public class AuditPojo {
	@Id
	@GeneratedValue
	private Integer id;
	@Column(name="property_name")
	private String propertyName;
	private String previousvalue;
	private String currentvalue;
	private String className;
	private Date dateofchange;
	private String user;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public String getPreviousvalue() {
		return previousvalue;
	}
	public void setPreviousvalue(String previousvalue) {
		this.previousvalue = previousvalue;
	}
	public String getCurrentvalue() {
		return currentvalue;
	}
	public void setCurrentvalue(String currentvalue) {
		this.currentvalue = currentvalue;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Date getDateofchange() {
		return dateofchange;
	}
	public void setDateofchange(Date dateofchange) {
		this.dateofchange = dateofchange;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	
}
