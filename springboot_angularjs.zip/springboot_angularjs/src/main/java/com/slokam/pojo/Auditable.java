package com.slokam.pojo;

public interface Auditable {

}
