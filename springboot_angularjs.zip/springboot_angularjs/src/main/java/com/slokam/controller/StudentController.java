package com.slokam.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.slokam.pojo.StudentPojo;
import com.slokam.service.AuditingService;
import com.slokam.service.IStudentService;

@RestController
@RequestMapping("student")
public class StudentController {
	@Autowired
	IStudentService ser;
	
	
	@RequestMapping(method=RequestMethod.POST)
	@Secured("ROLE_ADMIN")
	public void saveOrUpdateStudent(@RequestBody StudentPojo currentObj){
		
		ser.saveOrUpdateStudent(currentObj);
		
	}
	@RequestMapping(value="/all",method=RequestMethod.GET)
	@Secured(value={"ROLE_ADMIN","ROLE_USER"})
	
	List<StudentPojo> getAllStudents(){
		List<StudentPojo> students=ser.getAllStudents();
		return students;
		}
	@RequestMapping(value="/{id}",method=RequestMethod.DELETE)
	@Secured("ROLE_ADMIN")
	public void deleteStudent(@PathVariable Integer id){
		StudentPojo p=new StudentPojo();
		p.setId(id);
		ser.deleteStudent(p);
		
	}
	@RequestMapping(value="/{stdid}",method=RequestMethod.GET)
	@Secured("ROLE_ADMIN")
	StudentPojo getByStudentId(@PathVariable("stdid") Integer id,HttpSession httpSession){
		
	StudentPojo student=	ser.getByStudentId(id);
	httpSession.setAttribute("preobj", student);
		return student;
		} 
}
