package com.slokam.controller;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.slokam.pojo.LoginPojo;

@RestController
public class LoginController {
	@RequestMapping("loginsuccess")
	public LoginPojo loginSuccess(){
		LoginPojo loginPojo =new LoginPojo();
		SecurityContext context=	SecurityContextHolder.getContext();
		Collection<? extends GrantedAuthority> list=context.getAuthentication().getAuthorities();
		for (GrantedAuthority grantedAuthority : list) {
			loginPojo.setMessage(grantedAuthority.getAuthority());
		}
		
		loginPojo.setCode("101");
		
		return loginPojo;
	}
	@RequestMapping("failure")
  public LoginPojo loginFailure(){
		LoginPojo loginPojo=new LoginPojo();
		loginPojo.setCode("102");
		loginPojo.setMessage("invalidcredentials please enter valid details");
		return loginPojo;
		
	}
	@RequestMapping("logouturl")
	  public String logout(){
	SecurityContext context=	SecurityContextHolder.getContext();		
	context.getAuthentication().setAuthenticated(false);
	return "logoutsuccesfully";
	}
	
}
