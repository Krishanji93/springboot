package com.slokam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.slokam.dao.Hibernate_Dao;
import com.slokam.pojo.StudentPojo;
@Service
public class StudentService implements IStudentService{
	
	@Autowired
	Hibernate_Dao dao;
	
	@Autowired
	AuditingService aud;

	
	@Override
	public List<StudentPojo> getAllStudents() {
		List<StudentPojo> list=dao.findAll();
		return list;
	}

	@Override
	@Transactional
	public void saveOrUpdateStudent(StudentPojo s) {
		dao.save(s);
		
	}
	@Override
	@Transactional
	public void  deleteStudent(StudentPojo s) {
		dao.delete(s);
	}

	@Override
	public StudentPojo getByStudentId(Integer id) {
		StudentPojo s=dao.findOne(id);
		return s;
	}

	

}
