package com.slokam.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.slokam.dao.UserDao;
import com.slokam.pojo.GrantedAuthoritiesImpl;
import com.slokam.pojo.UserDetailPojo;
@Service
public class UserDetailsServiceImpl implements UserDetailsService{
	
	@Autowired
	private UserDao userdao;
	
	@Override
	public UserDetails loadUserByUsername(String arg0) throws UsernameNotFoundException {
	
		List<UserDetailPojo> users=	 userdao.getByUsername(arg0);
	
	List<GrantedAuthoritiesImpl> auths=		userdao.getAuthorities(arg0);
	users.get(0).setAuthorities(auths);
	/*System.out.println(users.get(0));
	GrantedAuthoritiesImpl auth=new GrantedAuthoritiesImpl();
	auth.setAuthority("ROLE_USER");
	Collection<GrantedAuthoritiesImpl> auths=new ArrayList<>();
	auths.add(auth);
	UserDetailPojo p=new UserDetailPojo();
	p.setPassword("krish8666");
	p.setAccountNonLocked(true);
	p.setAccountNonExpired(true);
	p.setCredentialsNonExpired(true);
	p.setEnabled(true);
	p.setAuthorities(auths);*/
		return users.get(0);
	}

}
