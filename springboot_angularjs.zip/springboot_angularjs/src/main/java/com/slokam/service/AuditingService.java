package com.slokam.service;



import java.beans.PropertyDescriptor;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.slokam.dao.AuditingDao;
import com.slokam.pojo.AuditPojo;



@Component
public class AuditingService {
	@Autowired
	private AuditingDao dao;
	@Transactional
	public void audit(Object preobj,Object currobj){
		String previousvalue=null;
		String currentvalue=null;
	if	(preobj!=null && currobj!=null){
	BeanWrapper bw=	PropertyAccessorFactory.forBeanPropertyAccess(preobj);
	PropertyDescriptor[] pd	=bw.getPropertyDescriptors();
	
		for (PropertyDescriptor propertyDescriptor : pd) {
		String name=	propertyDescriptor.getName();
		
		Object prvobjvalue=bw.getPropertyValue(name);
		//if(!prvobjvalue.equals(null))
			previousvalue=prvobjvalue+"";
			
				BeanWrapper bw1=	PropertyAccessorFactory.forBeanPropertyAccess(currobj);
			PropertyDescriptor[] pd1	=bw1.getPropertyDescriptors();
			
			for (PropertyDescriptor propertyDescriptor2 : pd1) {
				
				Object currobjvalue=bw1.getPropertyValue(name);
				//if(!currobjvalue.equals(null))
				currentvalue=currobjvalue+"";
				
				if((isNotEmpty(previousvalue) || isNotEmpty(currentvalue))  && !previousvalue.equals(currentvalue)){
					
					
					AuditPojo p=new AuditPojo();
					p.setCurrentvalue(currentvalue);
					p.setPreviousvalue(previousvalue);
					p.setDateofchange(new Date());
					p.setPropertyName(name);
					p.setClassName(currobj.getClass().getName());
					p.setUser(getUser());
					dao.save(p);
				}
			break;
			}
		
		}
		
	}
		
	} 
	public boolean isNotEmpty(String value){
		boolean result=false;
		if(value!=null && !value.trim().equals(""))
		result=true;
		return result;
	
	}
	public String getUser(){
		SecurityContext context=SecurityContextHolder.getContext(); 
		String user=context.getAuthentication().getName();
		return user;
	}
}
