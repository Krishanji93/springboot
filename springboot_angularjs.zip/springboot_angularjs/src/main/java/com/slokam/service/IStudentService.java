package com.slokam.service;

import java.util.List;

import com.slokam.pojo.StudentPojo;

public interface IStudentService {
	void saveOrUpdateStudent(StudentPojo s);
	List<StudentPojo> getAllStudents();
	void deleteStudent(StudentPojo s);
	StudentPojo getByStudentId(Integer id); 
}
