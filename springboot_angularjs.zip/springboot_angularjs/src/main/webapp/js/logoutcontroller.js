var module=angular.module("application");
module.controller("logoutcontroller",function($http,$location){
	$http.get("/logouturl").success(function(data, status, headers, config) {
		alert("logoutsuccesful")
		$location.path("/login")
	}).error(function(data, status, headers, config) {
		alert("logoutfail")
	})
})