var module=angular.module("application",[]);
module.config(function($routeProvider){
	$routeProvider.when("/login",{templateUrl:"html/login.html",controller:"logincontroller"})
	$routeProvider.when("/home",{templateUrl:"html/home.html"})
	$routeProvider.when("/student",{templateUrl:"html/student.html",controller:"studentcontroller"})
	$routeProvider.when("/logout",{templateUrl:"html/login.html",controller:"logoutcontroller"})
});

module.controller("studentcontroller",function($scope,$http){
	$scope.saveorupdate=function(){
		alert($scope.stdent.name)
		$http.post("student",$scope.stdent).success(function(data, status, headers, config) {
			alert("Success "+status)
		}).error(function(data, status, headers, config) {
			alert("error "+$scope.stdent.name+$scope.stdent.age)
		})
		$scope.stdent={}
		$scope.getallstudents();	
	}
	
	$scope.getallstudents= function(){
		$http.get("student/all").success(function(data, status, headers, config) {
		alert("success "+data)
			$scope.students=data
		}).error(function(data, status, headers, config) {
			alert("error")
		})
		
	}
	$scope.getbyid =function(id){
		$http.get("student/"+id).success(function(data, status, headers, config) {
			
			alert("success getbyid "+data)
			$scope.stdent=data
		}).error(function(data, status, headers, config) {
			alert("error")
		})
	}
	$scope.deletestudent= function(id){
		$http.delete("student/"+id).success(function(data, status, headers, config) {
			
			alert("success delet "+data)
			$scope.stdent=data
	}).error(function(data, status, headers, config) {
		alert("error")
	})
	$scope.stdent={}
		$scope.getallstudents();
	}
})