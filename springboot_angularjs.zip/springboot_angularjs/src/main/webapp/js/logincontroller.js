var module=angular.module("application");
module.controller("logincontroller",function($scope,$http,$location){
	
	$scope.login= function(){
		
	$http.post("/loginProcessingUrl?user="+$scope.user+"&password="+$scope.password).success(function(data, status, headers, config) {
		alert(data.message)
		$scope.message=data.message;
		if(data.code=="101"){
			$location.path("/student")
		}
	}).error(function(data, status, headers, config) {
		alert("loginfail")
	})
	}
});