package com.slokam;

import static org.junit.Assert.*;

import org.junit.Test;

public class FirstTest {

	@Test
	public void test() {
		fail("Not yet implemented");
		
	}

}
