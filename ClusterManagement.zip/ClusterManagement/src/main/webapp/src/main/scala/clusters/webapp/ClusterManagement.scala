package clusters.webapp

import scala.scalajs.js
import org.scalajs.dom
import dom.html
import org.scalajs.dom.html.{Div, Button, Input}
import org.scalajs.dom.raw.MouseEvent
import scalajs.js.annotation._
import scalatags.JsDom.all._
import dom.document
import dom.ext.Ajax
import org.scalajs.dom.XMLHttpRequest
import scala.scalajs.js.JSON

@JSExport
object ClusterManagement extends{

	 var user =input(`type`:="text").render
	 var password=input(`type`:="password").render
	 var login=button("Login").render

  @JSExport
   def main(target: html.Div): Unit = {
  		target.appendChild(
      
      div(table(thead(tr(th("Login "),th(""))),tbody(tr(td(span("UserName  ")),td(user)),tr(td(span("Password  ")),td(password)),tr(td(login)))//tbody
              
            )
      ).render

    )

  		login.onclick = (x: MouseEvent) =>{

  				val xhr = new XMLHttpRequest()
  				xhr.open("POST","auth?user="+user.value+"&password="+password.value)
  				
  				xhr.onload = { (e: dom.Event) =>
  				if (xhr.status == 200) {
    			println("Role   "+xhr.responseText)
          /*val role = JSON.parse(xhr.responseText);
          dom.console.log(role)
              if(!(role=="undefined")){
  				 var auth:String=role.user_roles.toString
           println(auth)
           }
          */ getClusterDetails(target)
                 
 				 }
			
				}
        
				xhr.send()
  			
  		}

    
}

 	 def getClusterDetails(target:html.Div):Unit={
    val xhr = new XMLHttpRequest()
          xhr.open("GET","clusters/all")
          
          xhr.onload = { (e: dom.Event) =>
          if (xhr.status == 200) {
          println("Clusterssssss list  "+xhr.responseText)
          val clusterlist = JSON.parse(xhr.responseText)
           dom.console.log(clusterlist)
          var rolee:js.Dynamic=clusterlist.role;
          println("getroleee  "+rolee.toString)
         var list:js.Array[js.Dynamic] =clusterlist.clusters_details.asInstanceOf[js.Array[js.Dynamic]]
            showClusters("",target,list,rolee.toString)
            //refreshScreen(target,list,rolee.toString)
         }
      
        }
        
        xhr.send()
        


   }

   /*def refreshScreen(target:html.Div,list:js.Array[js.Dynamic],role:String):Unit={
         for(i<-list){
          println(i.cluster_name)
         }
         showClusters(target,list,role)
   }*/

	def showClusters(message:String,target:html.Div,list:js.Array[js.Dynamic],role:String):Unit={
			target.innerHTML=""
			
			target.appendChild(
					div(h4(message),h1("CLUSTER DETAILS"),div(float:="right")(a(href:="logout")("Logout")),
            table(
              tr(
                th("CLUSTER NAME"),th("NO OF NODES"),th("")
              ),for (it <- list.toSeq) yield
              tr(
                td()(div(s"${it.cluster_name}")),td(if(role=="ROLE_ADMIN")div(s"${it.numberOfNodes}",editable(it,target,role)),
                if(role=="ROLE_USER"){
                  div(span(s"${it.numberOfNodes}"))
                }
              )
              )
            )//table
					
			
				).render
			)


	}
    def inputField(it:js.Dynamic)={
      
      val inputf = input(value:=it.numberOfNodes).render
    inputf.onkeyup = { (e: dom.Event) =>
         println("onkeyin  "+inputf.value)
         it.numberOfNodes=inputf.value

    }        
    inputf
    }
  def editable(it:js.Dynamic,target:html.Div,role:String) = {
    val edit = button("edit").render
    edit.onclick = (_: MouseEvent) => {
        //println("onupdate"+b.value)


      
      target.appendChild(div(inputField(it),updateButton(it,target,role)).render)

     /* updateCluster(it,target,role)*/
      
    }
    edit
  }
  def updateButton(it:js.Dynamic,target:html.Div,role:String) = {
    val b = button("update").render
    b.onclick = (_: MouseEvent) => {
        println("onupdate"+b.value)


      
     // target.appendChild(inputField(it),updateButton(it,target,role))

      updateCluster(it,target,role)
      
    }
    b
  }

  def updateCluster(cluster:js.Dynamic,target:html.Div,role:String){
    println(JSON.stringify(cluster))
     val xhr = new XMLHttpRequest()

     xhr.open("PUT","clusters/update")
      //?cluster_id="+cluster.cluster_id+"&cluster_name="+cluster.cluster_name+"&cluster.numberOfNodes="+cluster.numberOfNodes
     xhr.setRequestHeader("Content-type","application/json;charset=utf-8")
     xhr.onload = { (e: dom.Event) =>
          if (xhr.status == 200) {
            val clusterlist = JSON.parse(xhr.responseText)
           dom.console.log(clusterlist)
          
         var list:js.Array[js.Dynamic] =clusterlist.clusters_details.asInstanceOf[js.Array[js.Dynamic]]
          showClusters("Udated Succesfully",target,list,role)
         }
      
        }
        var clusterJson=JSON.stringify(cluster)
        xhr.send(clusterJson)

  }
/*  @dom
def bindingInput(clustname:Var[String],cluster:js.Dynamic): Binding[Input] = {
  <input
    cluster.cluster_name:
    
  >
   Modify the name
  </input>
}*/
/*@dom
def table(data:js.Array[js.Dynamic]): Binding[Table] = {
  <table border="1" cellPadding="5">
    <thead>
      <tr>
        <th>CLuster Name</th>
        <th>Number OF Nodes</th>
      </tr>
    </thead>
    <tbody>
      {
        for (cluster <- data) yield {
          <tr>
            <td>
              {cluster.cluster_name.bind}
            </td>
            <td>
              {cluster.numberOfNodes.bind}
            </td>
          </tr>
        }
      }
    </tbody>
  </table>
}*/

}


case class Cluster(cluster_id: js.Dynamic,cluster_name:js.Dynamic,numberOfNodes:js.Dynamic)
/*@js.native
trait Clusters extends js.Object{

val cluster_details : js.Array[Cluster]
  
}*/
@js.native
trait Role extends js.Object{
  val user_roles:String
}  

@js.native
trait Clusters extends js.Object{

val clusters_details : js.Array[Cluster]
  
}