package com.infy.clusters.application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.infy.clusters.dao.UserDetailsDao;

public class Userdetailsclient {
	@Autowired
	HibernateTemplate ht;
	public static void main(String[] args) {
		 
		
	}

}
