package com.infy.clusters.service;

import java.util.List;

import com.infy.clusters.dto.RespDTO;
import com.infy.clusters.pojo.ClusterPojo;

public interface ClusterIService {
	
	RespDTO updateClusterDetails(ClusterPojo clusterPojo);
	
	RespDTO getAllClusterDetails();
	
}
