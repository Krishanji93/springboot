package com.infy.clusters.configurations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable()
		.formLogin().loginPage("/index.html").permitAll().loginProcessingUrl("/auth")
		.usernameParameter("user").passwordParameter("password")
		.defaultSuccessUrl("/authenticated")
		.failureUrl("/authfail")
		.and().logout()
		.invalidateHttpSession(true)
		.logoutUrl("/logout").logoutSuccessUrl("/logoutsuccess")
		.clearAuthentication(true).and().authorizeRequests().antMatchers("/index.html","/target/scala-2.11/cluster-management-fastopt.js","cluster-management-opt.js").permitAll().anyRequest().authenticated();
		
	}
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("readonly").password("readonly").roles("USER").and().withUser("admin").password("admin").roles("ADMIN");
	//	auth.userDetailsService(userDetailsService);
	}

}
