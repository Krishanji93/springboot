package com.infy.clusters.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.infy.clusters.dao.UserDetailsDao;
import com.infy.clusters.pojo.UserDetailImpl;
@Service
public class UserDetailServiceImpl implements UserDetailsService{
	
	@Autowired
	private UserDetailsDao userdetailsdao;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		UserDetailImpl detailImpl=userdetailsdao.getByUsername(username).get(0);
		detailImpl.setAuthorities(userdetailsdao.getAuthorities(username));
		
		System.out.println("UserDetails "+detailImpl);
		return detailImpl;
	}
	

}
