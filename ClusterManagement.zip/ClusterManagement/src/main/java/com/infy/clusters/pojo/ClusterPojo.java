package com.infy.clusters.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="cluster_details")
public class ClusterPojo {
	@Id
	@GeneratedValue
	@Column
	private Long cluster_id;
	@Column
	private String cluster_name;
	@Column
	private Integer numberOfNodes;
	
	public String getCluster_name() {
		return cluster_name;
	}
	public void setCluster_name(String cluster_name) {
		this.cluster_name = cluster_name;
	}
	public Integer getNumberOfNodes() {
		return numberOfNodes;
	}
	public void setNumberOfNodes(Integer numberOfNodes) {
		this.numberOfNodes = numberOfNodes;
	}
	public Long getCluster_id() {
		return cluster_id;
	}
	public void setCluster_id(Long cluster_id) {
		this.cluster_id = cluster_id;
	}
	@Override
	public String toString() {
		return "ClusterPojo [cluster_id=" + cluster_id + ", cluster_name=" + cluster_name + ", numberOfNodes="
				+ numberOfNodes + "]";
	}
	
	
	

}
