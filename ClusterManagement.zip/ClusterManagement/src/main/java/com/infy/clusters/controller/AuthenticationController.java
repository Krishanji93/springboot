package com.infy.clusters.controller;

import java.util.Collection;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.clusters.dto.LoginResp;

@RestController
public class AuthenticationController {
	@RequestMapping("/authenticated")
	public ResponseEntity<LoginResp> authenticated(){
		
		SecurityContext context=	SecurityContextHolder.getContext();
		Collection<? extends GrantedAuthority> roles=context.getAuthentication().getAuthorities();
		String role = null;
		for(GrantedAuthority auuth :roles){
			role=auuth.getAuthority();
		}
		return new ResponseEntity<LoginResp>(new LoginResp(role),HttpStatus.OK) ;
		
	}
	
	@RequestMapping("/authfail")
	public ResponseEntity<String> authFail(){
		
		return new ResponseEntity<String>("InValid Credentials",HttpStatus.OK) ;
	
	}
	
	@RequestMapping("/logoutsuccess")
	public ResponseEntity<String> logoutSuccess(){
		
		return new ResponseEntity<String>("Logged Out",HttpStatus.OK) ;
		}
	
	@RequestMapping("/login")
	public ResponseEntity<String> login(){
		
		return new ResponseEntity<String>("PLEASE LOGIN",HttpStatus.OK) ;
	
	}
	
}
