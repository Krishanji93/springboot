package com.infy.clusters.dto;

import java.util.List;

import com.infy.clusters.pojo.ClusterPojo;

public class RespDTO {
	
	public RespDTO(List<ClusterPojo> clusters){
		this.clusters_details=clusters;
		
	}
	
	private List<ClusterPojo> clusters_details;
	
	

	public List<ClusterPojo> getClusters_details() {
		return clusters_details;
	}

	public void setClusters_details(List<ClusterPojo> clusters_details) {
		this.clusters_details = clusters_details;
		
	}

	
}
