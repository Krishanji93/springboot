package com.infy.clusters.dto;

import java.util.List;

import com.infy.clusters.pojo.ClusterPojo;

public class RespDTO {
	
	public RespDTO(List<ClusterPojo> clusters,String roles){
		this.clusters_details=clusters;
		this.role=roles;
		
	}
	
	private List<ClusterPojo> clusters_details;
	private String role;
	

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<ClusterPojo> getClusters_details() {
		return clusters_details;
	}

	public void setClusters_details(List<ClusterPojo> clusters_details) {
		this.clusters_details = clusters_details;
		
	}

	
}
