package com.infy.clusters.pojo;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.springframework.security.core.userdetails.UserDetails;
@Entity
@Table(name="userdetails")
public class UserDetailImpl implements UserDetails{
	
	@Id
	@GeneratedValue
	@Column(name="user_id")
	private Long id;
	@Column
	private String username;
	@Column
	private String password;
	@Column
	private boolean accountNonExpired;
	@Column
	private boolean accountNonLocked;
	@Column
	private boolean credentialsNonExpired;
	@Column
	private boolean enabled;
	
	@ManyToMany
	@JoinTable(name="userauthorities",joinColumns={@JoinColumn(name="user_id")},inverseJoinColumns={@JoinColumn(name="authority_id")})
	private Collection<GrantedAuthoritiesImpl> authorities;
	
	
	@Override
	public Collection<GrantedAuthoritiesImpl> getAuthorities() {
		
		return this.authorities;
	}

	@Override
	public String getPassword() {
		
		return this.password;
	}

	@Override
	public String getUsername() {
		
		return this.username;
	}

	@Override
	public boolean isAccountNonExpired() {
		
		return this.accountNonExpired;
	}

	@Override
	public boolean isAccountNonLocked() {
		
		return this.accountNonLocked;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		
		return this.credentialsNonExpired;
	}

	@Override
	public boolean isEnabled() {
		
		return this.enabled;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAccountNonExpired(boolean accountNonExpired) {
		this.accountNonExpired = accountNonExpired;
	}

	public void setAccountNonLocked(boolean accountNonLocked) {
		this.accountNonLocked = accountNonLocked;
	}

	public void setCredentialsNonExpired(boolean credentialsNonExpired) {
		this.credentialsNonExpired = credentialsNonExpired;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public void setAuthorities(Collection<GrantedAuthoritiesImpl> authorities) {
		this.authorities = authorities;
	}

	@Override
	public String toString() {
		return "UserDetailImpl [username=" + username + ", password=" + password + ", authorities=" + authorities + "]";
	}
	
	

}
