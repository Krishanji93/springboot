package com.infy.clusters.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.clusters.dao.ClusterDao;
import com.infy.clusters.pojo.ClusterPojo;

@Service
public class ClusterService implements ClusterIService {
	
	@Autowired
	private ClusterDao clusterDao;

	@Override
	@Transactional
	public List<ClusterPojo> updateClusterDetails(ClusterPojo clusterPojo) {
					clusterDao.save(clusterPojo);
						return clusterDao.findAll();
	}

	
	@Override
	public List<ClusterPojo> getAllClusterDetails() {
		
		return clusterDao.findAll();
	}
	
		

}
