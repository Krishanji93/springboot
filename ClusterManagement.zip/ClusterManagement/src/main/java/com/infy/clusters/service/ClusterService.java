package com.infy.clusters.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.clusters.dao.ClusterDao;
import com.infy.clusters.dto.RespDTO;
import com.infy.clusters.pojo.ClusterPojo;

@Service
public class ClusterService implements ClusterIService {
	
	
	@Autowired
	private ClusterDao clusterDao;
	
	
	@Override
	@Transactional
	public RespDTO updateClusterDetails(ClusterPojo clusterPojo) {
					clusterDao.save(clusterPojo);
						return new RespDTO(clusterDao.findAll(),getRole());
	}

	
	@Override
	public RespDTO getAllClusterDetails() {
		
		return new RespDTO(clusterDao.findAll(),getRole());
	}
	
		public String getRole(){
			
			SecurityContext context=	SecurityContextHolder.getContext();
			Collection<? extends GrantedAuthority> roles=context.getAuthentication().getAuthorities();
			String role=null;
			for(GrantedAuthority rolee:roles){
				role=rolee.getAuthority();
				}
			return role;
			
		}

}
