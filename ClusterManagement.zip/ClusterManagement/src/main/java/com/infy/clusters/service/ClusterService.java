package com.infy.clusters.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.clusters.dao.ClusterDao;
import com.infy.clusters.dto.RespDTO;
import com.infy.clusters.pojo.ClusterPojo;

@Service
public class ClusterService implements ClusterIService {
	
	@Autowired
	private ClusterDao clusterDao;

	@Override
	@Transactional
	public RespDTO updateClusterDetails(ClusterPojo clusterPojo) {
					clusterDao.save(clusterPojo);
						
						return new RespDTO(clusterDao.findAll());
	}

	
	@Override
	public RespDTO getAllClusterDetails() {
		
		return new RespDTO(clusterDao.findAll());
	}
	
		

}
