package com.infy.clusters.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.security.core.GrantedAuthority;
@Entity
@Table(name="authoritiesdetails")
public class GrantedAuthoritiesImpl implements GrantedAuthority{
	
	@Id
	@GeneratedValue
	@Column(name="authority_id")
	private Integer id;
	@Column
	private String authorities;

	@Override
	public String getAuthority() {
		
		return this.authorities;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setAuthority(String authority) {
		this.authorities = authorities;
	}


}
