package com.infy.clusters.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.clusters.pojo.ClusterPojo;

@Repository
public interface ClusterDao extends JpaRepository<ClusterPojo, Integer>{

}
