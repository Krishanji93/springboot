package com.infy.clusters.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.clusters.pojo.ClusterPojo;
import com.infy.clusters.service.ClusterIService;

@RestController
@RequestMapping("clusters")
public class ClusterController {
	
	@Autowired
	private ClusterIService clusterIService;
	
	@RequestMapping(value="/all",method=RequestMethod.GET)
	public ResponseEntity<List<ClusterPojo>> getAllClusterDetails(){
		return new ResponseEntity<List<ClusterPojo>>(clusterIService.getAllClusterDetails(), HttpStatus.OK);
		
			}
	@RequestMapping(value="/update",method=RequestMethod.PUT)
	public ResponseEntity<List<ClusterPojo>> updateClusterDetails(ClusterPojo clusterPojo){
		System.out.println("pojo"+clusterPojo);
		return new ResponseEntity<List<ClusterPojo>>(clusterIService.updateClusterDetails(clusterPojo), HttpStatus.OK);
				
	}

}
