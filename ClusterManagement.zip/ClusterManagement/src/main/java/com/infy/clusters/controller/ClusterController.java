package com.infy.clusters.controller;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.clusters.dto.RespDTO;
import com.infy.clusters.pojo.ClusterPojo;
import com.infy.clusters.service.ClusterIService;

@RestController
@RequestMapping("clusters")
public class ClusterController {
	
	@Autowired
	private ClusterIService clusterIService;
	
	@RequestMapping(value="/all",method=RequestMethod.GET)
	
	public ResponseEntity<RespDTO> getAllClusterDetails(){
		SecurityContext context=	SecurityContextHolder.getContext();
			if(	context.getAuthentication().isAuthenticated())
		return new ResponseEntity<RespDTO>(clusterIService.getAllClusterDetails(), HttpStatus.OK);
			return new ResponseEntity<RespDTO>(HttpStatus.NON_AUTHORITATIVE_INFORMATION);
		
			}
	@RequestMapping(value="/update",method=RequestMethod.PUT)
	public ResponseEntity<RespDTO> updateClusterDetails(@RequestBody ClusterPojo clusterPojo){
		System.out.println(clusterPojo);
		SecurityContext context=	SecurityContextHolder.getContext();
		Collection<? extends GrantedAuthority> roles=context.getAuthentication().getAuthorities();
		for(GrantedAuthority role:roles){
			System.out.println("AUTHORITY  "+role);
			if(role.getAuthority().equals( "ROLE_ADMIN")){
				return new ResponseEntity<RespDTO>(clusterIService.updateClusterDetails(clusterPojo), HttpStatus.OK);
			}
			
		}
		return new ResponseEntity<RespDTO>(HttpStatus.NON_AUTHORITATIVE_INFORMATION);
				
	}

}
