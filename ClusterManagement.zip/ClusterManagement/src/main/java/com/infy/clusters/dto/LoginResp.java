package com.infy.clusters.dto;

import java.util.Collection;

public class LoginResp {

	
	private String user_roles;
		
	public LoginResp(String roles){
		this.user_roles=roles;
		
	}

	public String getUser_roles() {
		return user_roles;
	}

	public void setUser_roles(String user_roles) {
		this.user_roles = user_roles;
	}
	
	
}
